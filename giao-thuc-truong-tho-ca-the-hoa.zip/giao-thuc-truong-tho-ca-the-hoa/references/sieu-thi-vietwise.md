# Danh mục Siêu Thị Vietwise dùng cho giao thức

Nguồn: https://sieuthivietwise.vn/35/ (đọc ngày 09/11/2026). Mã 35 trong đường dẫn là gian hàng của Chuyên gia Nhất Phương Hồng. Giá có thể thay đổi, kiểm lại trên trang trước khi gửi khách.


## Rửa thực phẩm, giảm tồn dư hoá chất

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [UMIKAI - Bột ngâm rửa rau củ quả thịt cá (100g)](https://sieuthivietwise.vn/35/UMIKAI--Bot-ngam-rua-rau-cu-qua-thit-ca-100g-324.html) | 219.000 đ | gene thải độc bất lợi (GST, CYP1A2, NFE2L2, UGT1A1), gan nhiễm mỡ/men gan cao, ăn nhiều rau quả sống, mẹ bầu và trẻ nhỏ | dùng để ngâm rửa, không ăn uống |
| [UMIKAI - Bột ngâm rửa (hộp giấy 20g, dùng thử)](https://sieuthivietwise.vn/35/UMIKAI--Bot-ngam-rua-rau-cu-qua-thit-ca-hop-giay-20g-812.html) | 65.000 đ | như trên, để dùng thử | — |
| [UMIKAI - Combo 2 hộp 100g tặng 1 hộp 20g](https://sieuthivietwise.vn/35/UMIKAI--Combo-2-hop-bot-ngam-rua-rau-cu-qua-thit-ca-100g-tang-1-hop-20g-814.html) | 438.000 đ | gia đình dùng đều | — |
| [FUWA3E - Combo 3 chai nước ngâm rửa thực phẩm (1 lít)](https://sieuthivietwise.vn/35/FUWA3E--Combo-3-chai-nuoc-ngam-rua-thuc-pham-1-Lit-843.html) | 183.000 đ | như Umikai, dạng nước | dùng để ngâm rửa, không ăn uống |

## Thực phẩm & đồ uống

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [LAMORI - Bột hạt khô không đường (400g)](https://sieuthivietwise.vn/35/LAMORI--Bot-hat-kho-khong-duong-400g-462.html) | 230.000 đ | không dung nạp lactose (MCM6 GG) thay sữa bò; cần chất béo tốt, đạm thực vật, bữa phụ no lâu | chọn loại KHÔNG đường khi có nguy cơ tiểu đường, HbA1c/đường đói/TG cao, kháng insulin; dị ứng hạt thì không dùng |
| [LAMORI - Bột đậu truyền thống không đường (400g)](https://sieuthivietwise.vn/35/LAMORI--Bot-dau-truyen-thong-khong-duong-400g-366.html) | 230.000 đ | đạm thực vật, thay sữa bò khi không dung nạp lactose, bữa sáng nhanh | chọn loại không đường như trên; acid uric cao thì dùng vừa phải |
| [LAMORI - Hạt nấu sữa Express (700g)](https://sieuthivietwise.vn/35/LAMORI--Hat-nau-sua-Express-700g-419.html) | 250.000 đ | tự nấu sữa hạt tại nhà, kiểm soát đường | dị ứng hạt thì không dùng |
| [LAMORI - Bánh hạt mầm nhẹ bụng (155g)](https://sieuthivietwise.vn/35/LAMORI--Banh-hat-mam-nhe-bung-155g-468.html) | 135.000 đ | bữa phụ thay bánh kẹo công nghiệp, người hay đói giữa buổi, huyết áp thấp cần bữa nhỏ | vẫn là tinh bột: tính vào khẩu phần, không ăn 3 giờ trước ngủ khi MTNR1B bất lợi |
| [LAMORI - Bột hạt thức giấc Mẹ Sữa không đường (400g)](https://sieuthivietwise.vn/35/LAMORI--Bot-hat-thuc-giac-Me-Sua-khong-duong-400g-463.html) | 230.000 đ | mẹ đang cho con bú cần năng lượng, đạm, chất béo từ hạt | dị ứng hạt thì không dùng |
| [LAMORI - Tô diệp lá (100g)](https://sieuthivietwise.vn/35/LAMORI--To-diep-la-100g-354.html) | 200.000 đ | lá tía tô khô pha trà: người hay đầy bụng, cảm lạnh nhẹ, cần đồ uống ấm không cafein | mang thai hỏi bác sĩ trước |
| [HOA BẢN - Trà tía tô cây toàn vẹn (200g)](https://sieuthivietwise.vn/35/HOA-BAN--Tra-tia-to-loai-cay-toan-ven-200g-445.html) | 120.000 đ | như Tô diệp lá, gói lớn tiết kiệm | mang thai hỏi bác sĩ trước |
| [LAMORI - Trà sen cúc (100g)](https://sieuthivietwise.vn/35/LAMORI--Tra-sen-cuc-100g-467.html) | 180.000 đ | trà thư giãn buổi tối, người khó ngủ, căng thẳng (gene giấc ngủ, CLOCK, MTNR1B, stress) | CÓ HOA CÚC: KHÔNG dùng khi dị ứng cỏ dại/họ Cúc (ragweed, mugwort); huyết áp thấp dùng loãng |
| [LAMORI - An Quế Trà (100g)](https://sieuthivietwise.vn/35/LAMORI--An-Que-Tra-100g-466.html) | 80.000 đ | trà ấm buổi sáng–chiều, người lạnh bụng, đường huyết sau ăn | có quế: lượng vừa phải khi dùng thuốc chống đông hoặc men gan cao; không dùng thay thuốc hạ đường |
| [NUTRIWORLD - Nấm mèo đen thái sợi (100g)](https://sieuthivietwise.vn/35/NUTRIWORLD--Nam-meo-den-thai-soi-100g-450.html) | 49.000 đ | tăng chất xơ hoà tan cho món ăn: LDL cao, táo bón, đường huyết sau ăn | dùng thuốc chống đông thì ăn lượng món ăn bình thường, không ăn nhiều đột ngột |
| [MƯỜI QUÝ - Nước mắm cốt đặc biệt (500ml)](https://sieuthivietwise.vn/35/MUOI-QUY--Nuoc-mam-cot-dac-biet-500ml-615.html) | 117.000 đ | thay nước mắm pha phụ gia; nêm thay muối và bột ngọt | nhiều natri: nhạy muối/tăng huyết áp thì ghi lượng (≤ 1 thìa canh/ngày); huyết áp thấp không cần cắt |
| [MƯỜI QUÝ - Nước mắm cho bé 100% cá cơm (60ml)](https://sieuthivietwise.vn/35/MUOI-QUY--Nuoc-mam-cho-be-100-ca-com-60ml-617.html) | 31.000 đ | gia đình có trẻ nhỏ ăn dặm | trẻ dưới 1 tuổi hỏi bác sĩ nhi về lượng muối |
| [Mật ong bạc hà Tinh Hoa Vị (100g)](https://sieuthivietwise.vn/35/Mat-ong-bac-ha-Tinh-Hoa-Vi-100g-395.html) | 120.000 đ | thay đường tinh luyện ở lượng nhỏ; ho, rát họng nhẹ | là ĐƯỜNG: không dùng hằng ngày khi tiểu đường, HbA1c/TG cao, acid uric cao; không cho trẻ dưới 1 tuổi |
| [LAMORI - Chanh rừng enzyme siro (500ml)](https://sieuthivietwise.vn/35/LAMORI--Chanh-rung-enzyme-siro-500ml-361.html) | 250.000 đ | đồ uống chua nhẹ thay nước ngọt | là siro có đường: tránh khi tiểu đường, TG cao, acid uric cao; trào ngược dạ dày dùng loãng |
| [GREENMED - Nước ép trái nhàu lên men Noni Biozen (500ml)](https://sieuthivietwise.vn/35/GREENMED--Nuoc-ep-trai-nhau-len-men-Noni-Biozen-500ml-649.html) | 590.000 đ | chỉ khi khách muốn và không có chống chỉ định | KHÔNG dùng khi: bệnh thận/eGFR < 60, kali > 5,0 hoặc dùng thuốc giữ kali (ACEi, ARB, spironolacton), men gan cao/gan nhiễm mỡ đang hoạt động, mang thai, cho con bú; không nêu công dụng chữa bệnh; theo dõi ALT/AST, kali |

## Tinh dầu (khuếch tán, xoa ngoài)

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [HOA NÉN - Tinh dầu oải hương (10ml)](https://sieuthivietwise.vn/35/HOA-NEN--Tinh-dau-oai-huong-10ml-510.html) | 110.000 đ | thư giãn trước ngủ (gene giấc ngủ, căng thẳng, lo âu): 2–3 giọt máy khuếch tán 30 phút trước giờ ngủ | chỉ khuếch tán hoặc pha loãng xoa ngoài, KHÔNG uống; hen suyễn, trẻ nhỏ, mang thai dùng rất loãng |
| [HOA NÉN - Tinh dầu Ngọc Lan Tây (10ml)](https://sieuthivietwise.vn/35/HOA-NEN--Tinh-dau-Ngoc-Lan-Tay-10ml-511.html) | 110.000 đ | thư giãn buổi tối, căng thẳng | KHÔNG uống; huyết áp thấp dùng ít |
| [HOA NÉN - Tinh dầu bạc hà (10ml)](https://sieuthivietwise.vn/35/HOA-NEN--Tinh-dau-bac-ha-10ml-506.html) | 85.000 đ | tỉnh táo buổi sáng, thay cafein khi phải 0 cafein (ADORA2A, cường giáp, tim nhanh) | KHÔNG uống, không dùng cho trẻ dưới 6 tuổi, tránh vùng mắt |
| [HOA NÉN - Tinh dầu bưởi (10ml)](https://sieuthivietwise.vn/35/HOA-NEN--Tinh-dau-buoi-10ml-508.html) | 95.000 đ | sảng khoái ban ngày | KHÔNG uống; tinh dầu họ cam chanh làm da nhạy nắng: không thoa rồi ra nắng |
| [HOA NÉN - Tinh dầu tràm Huế (10ml)](https://sieuthivietwise.vn/35/HOA-NEN--Tinh-dau-tram-Hue-10ml-495.html) | 55.000 đ | giữ ấm, cảm lạnh, gia đình có trẻ nhỏ | KHÔNG uống; trẻ nhỏ dùng loại xịt tràm cho bé |
| [HOA NÉN - Xịt tràm cho bé (100ml)](https://sieuthivietwise.vn/35/HOA-NEN--Xit-tram-cho-be-100ml-Vegan-513.html) | 90.000 đ | gia đình có trẻ nhỏ | KHÔNG uống |

## Chăm sóc cá nhân ít hoá chất

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [COBOTÉ - Dầu dừa tươi đa năng (100ml)](https://sieuthivietwise.vn/35/COBOTE--Dau-dua-tuoi-da-nang-100ml-549.html) | 135.000 đ | da khô, dưỡng da tóc thay sản phẩm nhiều hương liệu; gene thải độc/nội tiết bất lợi | dùng ngoài; dị ứng dừa thì không dùng |
| [COBOTÉ - Sữa rửa mặt da nhạy cảm phong lữ (150ml)](https://sieuthivietwise.vn/35/COBOTE--Sua-rua-mat-cho-da-nhay-cam-phong-lu-150ml-715.html) | 195.000 đ | da nhạy cảm, viêm da, giảm phơi nhiễm hoá chất mỹ phẩm | thử trước vùng nhỏ |
| [COBOTÉ - Kem đánh răng than dừa (100g)](https://sieuthivietwise.vn/35/COBOTE--Kem-danh-rang-than-dua-100g-Coco-Miracle-Toothpaste-806.html) | 135.000 đ | vệ sinh răng miệng (viêm nướu liên quan viêm toàn thân, tim mạch, đường huyết) | vẫn đánh răng 2 lần/ngày và khám nha 6 tháng/lần |
| [COBOTÉ - Dầu súc miệng (200ml)](https://sieuthivietwise.vn/35/COBOTE--Dau-suc-mieng-200ml-521.html) | 165.000 đ | như trên | không nuốt |
| [COBOTÉ - Dầu gội dưỡng sinh (480ml)](https://sieuthivietwise.vn/35/COBOTE--Dau-goi-duong-sinh-480ml-707.html) | 395.000 đ | rụng tóc, da đầu nhạy cảm, giảm hoá chất | rụng tóc nhiều vẫn cần xét nghiệm ferritin, tuyến giáp |
| [MỘC HƯƠNG - Gel tắm hương nhu gừng (420ml)](https://sieuthivietwise.vn/35/MOC-HUONG--Gel-tam-huong-nhu-gung-420ml-477.html) | 325.000 đ | tắm ấm buổi tối cho giấc ngủ, người lạnh tay chân | thử trước vùng nhỏ |
| [MỘC HƯƠNG - Dầu pha tắm thảo mộc (144ml)](https://sieuthivietwise.vn/35/MOC-HUONG--Dau-pha-tam-thao-moc-150g--144ml-659.html) | 275.000 đ | ngâm chân/tắm thảo mộc trước ngủ, căng thẳng, đau mỏi | nước không quá nóng khi huyết áp thấp, tiểu đường có biến chứng thần kinh bàn chân |
| [COBOTÉ - Muối thảo mộc ngâm Ngọc Nữ An (310g)](https://sieuthivietwise.vn/35/COBOTE--Muoi-thao-moc-ngam-mong-Ngoc-Nu-An-310g-530.html) | 235.000 đ | phụ nữ sau sinh, chăm sóc vùng kín bằng ngâm thảo mộc | không dùng khi đang viêm nhiễm cần điều trị; hỏi bác sĩ sản |

## Gia dụng xanh (giảm hoá chất trong nhà)

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [HOA NÉN - Gel rửa chén thảo mộc (500ml)](https://sieuthivietwise.vn/35/HOA-NEN--Gel-rua-chen-thao-moc-500ml-Vegan-520.html) | 125.000 đ | gene thải độc/nội tiết bất lợi, hen, da tay nhạy cảm, nhà có trẻ nhỏ | — |
| [HOA NÉN - Gel lau sàn thảo mộc (500ml)](https://sieuthivietwise.vn/35/HOA-NEN--Gel-lau-san-thao-moc-500ml-Vegan-519.html) | 115.000 đ | như trên, nhà có trẻ bò, thú cưng | — |
| [ORENJI - Nước giặt hương Ly (3,8 lít)](https://sieuthivietwise.vn/35/ORENJI--Nuoc-giat-huong-Ly-38-Lit-625.html) | 160.000 đ | da nhạy cảm, viêm da, giảm hoá chất trên quần áo | — |
| [ORENJI - Rửa chén sả (3,8 lít)](https://sieuthivietwise.vn/35/ORENJI--Rua-chen-sa-38-Lit-624.html) | 165.000 đ | gia đình đông người, như gel rửa chén | — |

## Môi trường ngủ & thiết bị

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [ECO G9 - Màng chắn sóng điện từ (1 cái)](https://sieuthivietwise.vn/35/ECO-G9--Mang-chan-song-dien-tu-hinh-logo-STVW--1-cai-353.html) | 199.000 đ | chỉ khi khách quan tâm sóng điện thoại lúc ngủ | CHƯA có bằng chứng lâm sàng về tác dụng sức khoẻ: không hứa hiệu quả; việc chính vẫn là để điện thoại xa giường ≥ 1 m, chế độ máy bay, tắt màn hình 60 phút trước ngủ |
| [G9 - Bóng quang từ (1 trái)](https://sieuthivietwise.vn/35/G9--Bong-quang-tu-781.html) | 199.000 đ | chỉ khi khách quan tâm | CHƯA có bằng chứng lâm sàng: không nêu công dụng sức khoẻ, không thay giao thức ánh sáng và giấc ngủ |

## Gói dịch chuyển tiêu dùng

| Sản phẩm | Giá | Hợp với | Lưu ý |
|---|---|---|---|
| [VIETWISE - Combo Cả nhà khoẻ (5 món)](https://sieuthivietwise.vn/35/VIETWISE--Combo-Ca-nha-khoe-goi-5-mon-835.html) | 2.983.000 đ | gia đình nhiều thế hệ muốn đổi một lần cả nhóm đồ dùng hằng ngày (bột hạt cacao, mật ong, nước mắm, nước giặt, kem đánh răng) | có bột hạt CÓ đường và mật ong: không hợp người tiểu đường, TG cao, acid uric cao |
| [VIETWISE - Combo Bếp sạch, nhà thơm (5 món)](https://sieuthivietwise.vn/35/VIETWISE--Combo-Bep-sach-nha-thom-goi-5-mon-836.html) | 2.467.000 đ | đổi đồ bếp và tẩy rửa trong nhà sang loại ít hoá chất | — |
| [VIETWISE - Combo Mẹ và bé (5 món)](https://sieuthivietwise.vn/35/VIETWISE--Combo-Me-va-be-goi-5-mon-838.html) | 2.810.000 đ | mẹ bầu, mẹ cho con bú, nhà có trẻ nhỏ | — |
| [VIETWISE - Combo Trọn vẹn (5 món)](https://sieuthivietwise.vn/35/VIETWISE--Combo-Tron-ven-goi-5-mon-837.html) | 4.438.000 đ | gia đình muốn đổi toàn diện | — |

