---
name: "giao-thuc-truong-tho-ca-the-hoa"
description: "Dựng giao thức trường thọ cá thể hoá từ báo cáo gene Genetica G-Pro, xét nghiệm, cân điện tử/thiết bị đeo và lối sống: 3 chuyên gia phản biện, giao thức chi tiết, bản tóm tắt cốt lõi, thẻ nhắc theo giờ (có uống nước); kèm app chuyên gia trên Claude và app khách offline để nhắc lịch."
---

# Giao thức trường thọ cá thể hoá (SBIA × 3 chuyên gia)

Phương pháp của **Chuyên gia Nhất Phương Hồng**, đóng gói cùng Trợ lý Ai. Dùng khi người dùng gửi hồ sơ của chính mình hoặc của một khách (báo cáo gene Genetica G-Pro tiếng Việt hoặc tiếng Anh, ảnh bảng "Affected genes analyzed" trong app Genetica, xét nghiệm máu, siêu âm, đơn thuốc, ảnh cân điện tử hoặc thiết bị đeo, mô tả sinh hoạt, thuốc, thực phẩm – thảo dược đang dùng) và muốn có giao thức trường thọ / thuận gene cá thể hoá. Cũng dùng khi người dùng muốn **có app Giao Thức Trường Thọ của riêng mình** (mục 11).

Ngôn ngữ đầu ra: tiếng Việt. Gọi người được làm hồ sơ bằng tên. Tài liệu hỗ trợ lối sống song song với điều trị, không thay thế kết luận y khoa của bác sĩ. Gene là xu hướng; xét nghiệm và triệu chứng quyết định can thiệp.

## 0. Đầu vào: tối thiểu và bổ sung

**Chỉ cần báo cáo gene là chạy được.** Có báo cáo Genetica G-Pro + tên → bắt đầu ngay, không hỏi trước. Một người có thể có **tối đa 5 hồ sơ gene**: gộp lại, kết quả khác nhau giữa hai hồ sơ thì ghi rõ "Hồ sơ 1 / Hồ sơ 2"; tên trên các hồ sơ khác nhau thì báo một dòng.

Gửi thêm thì giao thức sát người hơn:
- **Xét nghiệm máu, siêu âm, đơn thuốc** → điền cột "Hiện tại" của biomarker, phát hiện bệnh đang hoạt động, chọn thực phẩm và thảo dược bù đúng thiếu hụt ĐÃ ĐO.
- **Sinh hoạt điển hình:** giờ ngủ, giờ ăn, tập luyện, công việc, stress, triệu chứng; **thuốc đang uống** (tên, liều, giờ); **thực phẩm – thảo dược – TPCN đang dùng và cách dùng**; tiền sử, dị ứng; mục tiêu của chính chủ.
- **Ảnh cân điện tử hoặc thiết bị đeo** (tối đa 7 ảnh): cân nặng, % mỡ, cơ, nước, nhịp tim nghỉ, HRV, giấc ngủ (tổng, sâu, REM), SpO2, số bước, VO2max, stress. Quy đổi lb → kg. Chỉ dùng để theo dõi xu hướng.
- **Ảnh bảng "Affected genes analyzed"** trong app Genetica → có vị trí SNP (rsID, GRCh38); báo cáo PDF chỉ in 2 gene tiêu biểu mỗi mục.

Thiếu phần nào vẫn làm: giờ giấc ghi "giả định", cột biomarker "Hiện tại" để trống và đánh "(Mới)", không đề xuất viên bổ sung (xem quy tắc thuận tự nhiên ở mục 1), phần thiếu đưa vào câu hỏi mở. Khi người dùng gửi bổ sung sau → cập nhật chính tài liệu đó, không tạo tài liệu mới.

## 1. Thu thập dữ liệu (làm trước, không đoán)

1. Liệt kê mọi file đính kèm; PDF lớn đọc bằng `pdftotext -layout` theo từng trang (`-f p -l p`) vào thư mục scratchpad riêng cho từng khách.
2. **Kiểm tra tên trên mọi tài liệu** so với tên người dùng gọi. Nếu khác, báo ngay một dòng và tiếp tục theo tên trên hồ sơ; khi người dùng xác nhận đó là tên gọi khác, ghi cả hai trong tiêu đề "<Tên hồ sơ> (<Tên gọi>)".
3. Trang ảnh (pdftotext trả ~1 ký tự): rasterize (`pdftoppm -r 110`), `convert -trim` để lấy đúng khung ảnh chụp điện thoại, crop vùng bảng GỒM CẢ cột Result, ghép lưới 3 cột (`montage`) rồi xem. Bảng dài hơn 5 dòng có thể bị cắt khi crop → đối chiếu thêm thumbnail toàn trang (`pdftoppm -r 40` + montage) cho các dòng cuối.
4. Báo cáo Genetica G-Pro — số trang thay đổi (314–318) → xác định mục bằng tiêu đề trang, không cố định số trang. Parse bằng script, xuất TSV (mục, gene, kiểu gen, phân loại, mức ảnh hưởng).
   - **Bản tiếng Việt:** `GENE` rồi `Kết quả: XX` + `(nguy cơ|bất lợi|bình thường|có lợi)`; `Ảnh hưởng tới ...: CAO/KHÁ CAO/TRUNG BÌNH/THẤP`. Điểm: trang "TÓM TẮT" → số sau "BẠN" + "Nhóm x% đầu/cuối dân số Châu Á". Ung thư: "KHÔNG PHÁT HIỆN … trong N gen". Đỏ mặt do rượu: "Tìm thấy / Không tìm thấy biến thể bất lợi".
   - **Bản tiếng Anh:** `GENE` rồi `Result: XX` + `(harmful|risk|normal|beneficial)`; `Impact to ...: HIGH/MEDIUM HIGH/MEDIUM/LOW`. Điểm: trang "SUMMARIZED ANALYSIS" → số dưới "You" + "Top/Bottom x% of Asian population". Ung thư: "WE DID NOT DETECT ANY PATHOGENIC OR LIKELY PATHOGENIC MUTATION in N genes analyzed". Đỏ mặt do rượu ("ASIAN FLUSH"): "No harmful variant found".
   - Cả hai bản chỉ in 2 gene tiêu biểu/mục và không ghi vị trí SNP → bảng gene đầy đủ và rsID cần ảnh chụp app Genetica (vị trí GRCh38). Không có ảnh → ghi rõ trong bảng gene và câu hỏi mở, không tự gán rsID.
   - Cùng một gene (vd MTHFR GG) có thể bị gắn "bất lợi" ở mục này và "có lợi" ở mục khác — ghi theo từng mục, không tự kết luận.
   - Đọc phần giải thích của những mục có gene bất lợi liên quan bệnh hiện tại (vd SLC4A7 trong mục khoáng chất có cảnh báo liệt chu kỳ hạ kali do tuyến giáp).
5. Xét nghiệm, siêu âm: ghi giá trị + khoảng tham chiếu + ngày + nơi làm + máy xét nghiệm nếu có (Roche Cobas, Abbott Alinity…). Nhiều lần xét nghiệm → bảng xu hướng theo ngày; không so trực tiếp kết quả giữa hai hãng máy (vd TRAb Roche U/L vs Abbott IU/L). Dấu "+"/"-" hoặc chữ đậm/gạch chân là ngoài ngưỡng.
6. Ghi chú sinh hoạt: giờ ăn, ngủ, tập, giờ ngồi, bệnh mạn, bệnh đã khỏi, thuốc đang dùng, mong muốn. Thiếu ghi chú → vẫn làm, giờ giấc ghi là giả định, thuốc và triệu chứng đưa vào câu hỏi mở.
7. Nơi sống: suy từ địa chỉ lab/hồ sơ mới nhất. Hai nơi khác nhau (vd Hà Nội và TP.HCM) → bảng thực phẩm có cột cho cả hai và hỏi lại.
8. Kiểm tra đơn vị bất thường (vd "vitamin D 1000mg/2000mg" → gần chắc là IU) và đưa vào câu hỏi mở. Thiếu chiều cao khi mục tiêu là cân nặng → hỏi.

## 2. Khung phân tích SBIA (bắt buộc)

- Thứ bậc can thiệp: Tầng 1 nhịp sinh học & ánh sáng → Tầng 2 dinh dưỡng nguyên bản (nutrigenomics) → Tầng 3 thảo dược và thực phẩm cô đặc tự nhiên theo SNP.
- **Thuận tự nhiên — không thực phẩm chức năng** (chị Hồng chốt 09/11/2026, ca gốc: giao thức của chính chị bị đề xuất creatine): không bao giờ đề xuất thực phẩm chức năng hay viên bổ sung tổng hợp (creatine, whey, viên vitamin, viên khoáng, dầu cá viên, collagen, NMN, CoQ10, probiotic viên…). Mỗi nhu cầu giải bằng thực phẩm nguyên bản đúng mùa (có món, có lượng) và thảo dược Việt Nam. Thiếu hụt nặng mà thực phẩm khó bù (B12, vitamin D, sắt rất thấp…) thì ghi vào "Cần trao đổi với bác sĩ", không tự kê viên. Toa khách đang dùng vẫn đánh giá theo mục 4b.
- **Thuốc tây có dấu (*)** ở mọi chỗ xuất hiện (bảng, lịch ngày, thẻ nhắc): theo đơn bác sĩ, không tự đổi liều hay ngưng.
- **Không trùng:** mỗi món một dòng, một thẻ. Tên chỉ khác thứ tự, dấu nối hay chữ "và" là một món ("D3 và K2" = "D3-K2" = "K2-D3"). App tự lọc khi chốt thẻ nhắc: gộp món trùng trong 90 phút, ghi "lần 2" nếu khác giờ, bỏ thực phẩm chức năng không nằm trong toa đang dùng, gắn (*) cho mọi thẻ Thuốc. Danh sách đã lọc ghi ở đầu mục 6.
- Weighted cross-check đa gen: mọi can thiệp soi qua các gene/triệu chứng/bệnh khác; can thiệp gây xung đột bị hạ trọng số hoặc phải có biện pháp trung hoà.
- Logic bắt buộc cho mỗi khuyến nghị chính: "Dựa trên xu hướng gen [X] và biểu hiện [Y], hành động [Z] là tối ưu vì [lý do]. Rủi ro [R] được kiểm soát bằng [biện pháp]."
- Mục tiêu của khách là trục chính; nút thắt nào chặn mục tiêu một cách nguy hiểm phải "kiểm tra trước, can thiệp sau" (tuần 0–2).
- **Chế độ bệnh đang hoạt động:** khi xét nghiệm/siêu âm cho thấy một bệnh đang hoạt động cần điều trị (vd Basedow với TRAb dương, TSH bị ức chế, tim nhanh), đổi tiêu đề thành "Giao thức thuận gene & trường thọ — <Tên>", lead nêu rõ ưu tiên y khoa và vai trò hỗ trợ bác sĩ; chia **Giai đoạn 1 (bệnh hoạt động: bảo vệ, hạ tải)** và **Giai đoạn 2 (ổn định: trường thọ)**; tra cứu hướng dẫn lâm sàng bằng WebSearch/WebFetch và trích dẫn trong tài liệu; thêm mục "Đi cấp cứu ngay khi" và "Cần trao đổi với bác sĩ lần tái khám tới". Mọi thực phẩm bổ sung trong giai đoạn 1 đều (*).
- Không khuyên chung chung; mỗi dòng trong bảng ghi gene/chỉ số liên quan.

## 3. Đầu ra

Ba sản phẩm cho mỗi người, viết thành tài liệu (Docs) hoặc trong app:

### 3a. Giao thức chi tiết (khoảng 20 trang)

Tiêu đề "Giao thức trường thọ cá thể hoá — <Họ tên>" (bản "thuận gene & trường thọ" khi có bệnh hoạt động). Câu mở là kết luận. Các mục:

1. **Phân tích hệ thống** — (có bệnh: "Bức tranh lâm sàng" trước) bảng Nút thắt | Xu hướng gene | Biểu hiện thực tế | Ưu tiên (3–6 nút); điểm mạnh nền tảng; chuỗi tương tác.
2. **3 chuyên gia**: A Di truyền học, B Dinh dưỡng thuận tự nhiên (thực phẩm, thảo dược địa phương đúng mùa), C Holistic life coach. Mỗi người 4–5 ý, có va chạm thật.
3. **Phản biện chéo** + ma trận lợi ích/rủi ro, ghi phương án bị loại.
4. **Giao thức thống nhất**: nhịp sinh học → dinh dưỡng nguyên bản → thảo dược, thực phẩm cô đặc tự nhiên (≤ 5 thứ mới, nhắm thiếu hụt đã đo; không thực phẩm chức năng). Câu logic SBIA. Cấp độ 1 Hard reboot, Cấp độ 2 Bio-hacking có đích, Giai đoạn 2 nếu có bệnh. Thực phẩm đúng mùa theo nơi sống. Tránh.
5. **Lịch một ngày và nhịp tuần** (Giờ | Việc | Chi tiết | Gene/chỉ số). Giờ chưa biết → giả định; thuốc kê đơn ghi "theo đơn".
6. **Thẻ nhắc hằng ngày** (mục 3c).
7. **Đánh giá thuốc, thực phẩm, thảo dược đang dùng** (toa thuốc sinh mệnh): từng món một theo 5 mức Giữ / Giữ có điều chỉnh / Tạm dừng chờ xét nghiệm / Không dùng / Theo đơn, kèm giờ và liều trong lịch mới, lý do + gene, xét nghiệm theo dõi (xem mục 4b).
8. **Thành phần cơ thể & thiết bị đeo**: số đo, xu hướng, nối với gene nhịp sinh học, giấc ngủ, chuyển hoá; lượng đạm theo cân nặng.
9. **Hồ sơ di truyền hoàn chỉnh**: Hệ | Gene | rsID (nếu có) | Kiểu gen | Phân loại | Mục, điểm /10 | Ý nghĩa; gene liên quan bệnh hiện tại lên đầu.
9b. **Chùm siêu gene trường thọ** (mục 6 bên dưới).
10. **Theo dõi phenotype**: Nhóm | Chỉ số | Cách đo | Tần suất | Mục tiêu | Gene | Tuần 0 | 4 | 8 | 12.
11. **Biomarker**: Biomarker | Hiện tại | Khi nào | Ngưỡng y tế | Ngưỡng tối ưu | Ý nghĩa | Gene; hướng dẫn lấy máu.
12. **An toàn, câu hỏi còn mở, nguồn**: miễn trừ; Đi cấp cứu ngay khi; Cần trao đổi với bác sĩ; thông tin còn thiếu; nguồn dữ liệu.

### 3b. Bản tóm tắt cốt lõi (khoảng 3 trang)

Chỉ giữ điều mà bỏ qua sẽ gây hại hoặc mất phần lớn hiệu quả. Câu ≤ 20 từ, không lặp ý.

- **Phần 1 — Di truyền: điều không thể bỏ qua** (~1 trang): 2–3 câu giới thiệu + MỘT câu kết luận quan trọng nhất; bảng Gene (kiểu gen) | Nghĩa là gì | Việc phải làm, 3–5 dòng, chỉ gene gắn với bệnh hoặc chỉ số đang lệch; Điểm mạnh để dựa vào 2–3 gạch.
- **Phần 2 — Lối sống: 5 việc mỗi ngày** (~1 trang): đúng 5 việc đánh số (làm gì, khi nào, vì gene/chỉ số nào); **Tuyệt đối tránh** 3–5 gạch, gọi đúng tên món/thảo dược/thói quen có hại hoặc tương tác với thuốc.
- **Phần 3 — Lâm sàng: an toàn trước hết** (~1 trang): Chỉ số cần kéo về (≤ 6 dòng: Hiện tại | Mục tiêu 12 tuần); Thuốc: điều phải nhớ; Việc phải làm với bác sĩ (≤ 5); **Đi cấp cứu ngay khi** (2–4); 1 câu miễn trừ.

### 3c. Thẻ nhắc theo giờ (16–28 thẻ/ngày)

Bảng Giờ | Thẻ nhắc | Loại (Thuốc / Bổ sung / Thực phẩm / Thảo dược / **Uống nước** / Luyện tập / Theo dõi / Giấc ngủ) | Chi tiết (liều, cách làm) | Ngày | Giai đoạn | Gene/chỉ số. (*) = chờ xét nghiệm hoặc bác sĩ đồng ý. Phủ cả ngày: thức dậy, ánh sáng, thuốc đúng giờ trong đơn, bữa ăn có gợi ý cụ thể, vận động, đo/theo dõi, bổ sung, thảo dược, tắt màn hình, ngủ.

**Uống nước (bắt buộc 5–7 thẻ, mỗi thẻ ghi ml):** tổng ≈ 30–35 ml × cân nặng (kg) đo thật; +400–600 ml mỗi giờ vận động ra mồ hôi; +300–500 ml khi trời nóng. Thức dậy 250–300 ml nước ấm; giữa buổi sáng; 15–30 phút trước bữa trưa và tối; giữa chiều; sau tập; ngừng uống nhiều 2 giờ trước ngủ. Uống từng ngụm, không uống nhiều trong bữa; cà phê, trà đặc, nước ngọt, nước ép không tính. Suy tim, suy thận nặng, phù, natri thấp, đang bị hạn chế dịch → "theo giới hạn dịch của bác sĩ". Đường huyết cao kèm khát, tiểu nhiều → uống đủ nhưng báo bác sĩ. Acid uric cao, sỏi → giữ ≥ 2 lít nếu không bị hạn chế dịch. Lợi tiểu, SGLT2 → nhắc uống đều.

### 3d. Màu cảnh báo

Mục nguy hiểm (Tuyệt đối tránh, Đi cấp cứu ngay khi, Cảnh báo, Không dùng) đặt trong khung **đỏ**; mục bác sĩ, thuốc, an toàn, lưu ý, xét nghiệm cần làm, câu hỏi còn mở đặt trong khung **cam**. Định dạng không có khung màu thì mở đầu tiêu đề bằng "CẢNH BÁO —" hoặc "LƯU Ý —". Màu nhân hiệu (tím #8a459a, hồng tím #ca41bc, xanh rêu #476e70, vàng #f5c70f, vàng nghệ #ecc459, kem #f5f1e8) chỉ cho tiêu đề thường.

## 4. Quy tắc an toàn & xung đột hay gặp (luôn kiểm tra)

- Đang dùng sulfonylurea (glimepiride, gliclazide…) → không nhịn ăn, không bỏ bữa, không low-carb gắt, không berberine; nhân sâm, sâm đen, lá ổi đậm đặc, mướp đắng viên cộng thêm hạ đường; dạy quy tắc 15; báo bác sĩ giảm liều khi đường đói nhiều ngày < 7 mmol/L.
- Người gầy (BMI bình thường) mà HbA1c rất cao → đề nghị bác sĩ thử kháng thể GAD + C-peptide để loại trừ LADA; không ăn kiêng giảm cân.
- Metformin dài ngày, gene B12 bất lợi → đo B12 mỗi năm. Gan nhiễm mỡ, men gan cao → tính FIB-4; hỏi bác sĩ thuốc có lợi cho gan. CASR bất lợi + thiếu xương + dấu hiệu xơ vữa → canxi từ thực phẩm, không viên canxi liều cao.
- Huyết áp thấp, mệt sau ăn → 300–400 ml nước trước bữa, 5–6 bữa nhỏ, đạm và rau trước tinh bột.
- Sản phẩm cần cẩn trọng: nước nhàu, chiết xuất lá ô liu khi huyết áp thấp, lá bạch hoa xà (độc khi uống), tóc tiên, tinh dầu dùng để ăn, máy nước "từ trường / ion kiềm / hồi sinh" (chưa có bằng chứng).
- Cân điện tử và thiết bị đeo chỉ để theo dõi xu hướng; không dùng khối xương của cân để chẩn đoán loãng xương, không dùng HRV/SpO2 của đồng hồ để chẩn đoán.

- Dị ứng cỏ dại (ragweed, sage/mugwort, sorrel, thistle) → tránh ngải cứu, atiso, hoa cúc, cúc la mã, echinacea (họ Cúc). Dị ứng phấn birch/alder → táo, đào, cà rốt, cần tây, hạt phỉ sống có thể ngứa miệng → nấu chín.
- Dễ bầm tím → không curcumin viên, ginkgo, dầu cá > 1 g, NSAID thường xuyên; gừng/nghệ/tỏi chỉ ở lượng gia vị; đề xuất PT/INR, aPTT.
- Sắt: chỉ bổ sung khi bác sĩ xác nhận (ferritin + CRP + TSAT); uống cách ngày + vitamin C; cách trà/cà phê 2 giờ. HFE C282Y âm tính giúp an toàn hơn.
- Nhóm nhạy muối (AGT rs699 GG, ACE GG, WNK1, EDN1) nhưng có tiền sử choáng/suýt ngất → đo huyết áp nằm–đứng 14 ngày trước khi khuyên giảm muối; ưu tiên thực phẩm giàu kali.
- Suýt ngất/ngất → khám nội trước khi tập cường độ cao; HIIT tối đa 1 buổi/tuần sau khi khám.
- Đi tiểu nhiều/tiểu đêm + gene tiểu đường cao (MTNR1B GG, CDKAL1, KCNJ11) → HbA1c, đường đói, insulin, tổng phân tích nước tiểu TRƯỚC khi tăng calo; không dùng thảo dược lợi tiểu (tầm ma/Brennnessel, râu ngô, atiso); uống nước chủ yếu trước 19h.
- Bạch cầu ái toan > 500/µl → gặp bác sĩ tìm nguyên nhân (dị ứng, ký sinh trùng — xét nghiệm phân, huyết thanh Strongyloides —, thuốc vừa dùng), IgE toàn phần; không tự tẩy giun hay dùng corticoid. Lympho thấp nhẹ → xét lại sau 4–6 tuần.
- Mẩn ngứa khi nóng/đổ mồ hôi (gợi ý mề đay cholinergic) → hỏi bác sĩ về kháng histamine; khó thở/phù môi khi tập → dừng, cấp cứu.
- Acid uric ≥ 6.8–7 (nhất là SLC17A1 CC, GCKR) → đạm ít purin, hạn chế nội tạng, cá mòi/cá cơm, nước hầm xương, bia, nước ngọt fructose; anh đào chua; nước đủ ban ngày.
- MCM6 rs4988235 GG → không sữa tươi; whey chỉ dùng isolate hoặc đạm đậu; canxi từ cá nhỏ, đậu phụ, mè, rau cải, sữa chua không lactose.
- ALDH2 rs671 → 0 rượu.
- MTNR1B rs10830963 G (đặc biệt GG) → không ăn tinh bột trong 3 giờ trước ngủ và ngay khi vừa dậy; không ép nhịn 16:8 nếu stress/ngủ kém (MC4R dễ bù ăn).
- ADORA2A TT → 1 cốc trà xanh trước 10h là toàn bộ cafein; ADORA2A TT + CYP1A2 chậm + tim nhanh/cường giáp/lo âu → 0 cafein. CYP1A2 AA + ADORA2A không TT → cafein trước 14h là đủ.
- Nguy cơ chấn thương cao (COL1A1, MMP3, ELN, IL1B, IGF2) → khởi động 10 phút, tăng tải ≤ 10%/tuần, collagen/gelatin 10–15 g + vitamin C 45–60 phút trước tập; bàn chân bẹt/đau lưng/vai → vật lý trị liệu, prehab hằng ngày, tạm bỏ nhảy rơi cao.
- Hồi phục ≤ 4/10 (SOD2 Val/Val, MLCK GG) + ≥ 5 buổi nặng/tuần → 4 buổi nặng + 1 buổi kỹ thuật/phục hồi.
- SOD2 rs4880 Val/Val, PPARGC1A TT → không vitamin C/E/NAC liều cao trong 2 giờ quanh buổi tập; zone 2 đều đặn.
- Tăng cân/tăng cơ: dư ~300 kcal, đạm 1.6–1.8 g/kg, +0.25–0.4 kg/tuần, đo vòng eo 2 tuần/lần; đạm lấy từ thực phẩm (cá, trứng, đậu phụ, thịt nạc), không bột đạm, không creatine, không mass gainer.
- Đau dạ dày sau HP → hạn chế NSAID; không ngồi khom ngay sau ăn; nội soi nếu đau đêm/phân đen.
- COMT Val/Met hoặc Met/Met → methylfolate ≤ 400 µg, buổi sáng, ngưng nếu bồn chồn. COMT Val/Val + BDNF Met/Met + nóng tính cao → quy tắc 90 giây, thở ra dài, không để đói > 4 giờ, magie tối.
- GSTP1 AA → vitamin E từ thực phẩm, không viên.
- BCO1/BCMO1 bất lợi → cần vitamin A sẵn (trứng, cá; gan 1 lần/tuần nếu acid uric bình thường).
- ETFDH TT → nhu cầu B2 cao khi tập nặng/nhịn ăn → thực phẩm giàu B2 hoặc B-complex (xem quy tắc biotin).
- Thải độc ≤ 3/10 (CYP1A1 CC, NAT2, NAT1, CYP3A) → tránh khói thuốc, thịt nướng cháy cạnh; rau họ cải.
- SLC4A7 bất lợi (hạ kali) → kali–magie từ thực phẩm, đo kali; tránh cam thảo và thảo dược lợi tiểu; không tự uống viên kali (nhất là WNK1 TT).
- **Biotin** làm sai xét nghiệm miễn dịch dùng streptavidin–biotin (TSH, FT4, FT3, TRAb, troponin, hormone…) → ngưng 3 ngày trước lấy máu; đọc nhãn B-complex, viên tóc–da–móng.
- **Cường giáp / Basedow đang hoạt động:** 0 cafein; tránh iod cao (rong biển, tảo, kelp, thuốc cản quang nếu tránh được) nhưng không cắt hẳn muối iốt; tránh cam thảo, nhân sâm, đông trùng, ashwagandha, viên tăng lực; không hút thuốc (bệnh mắt OR ~3.7); ăn đủ năng lượng–đạm, không nhịn ăn dài (đang dị hoá cơ); chỉ tập nhẹ khi nhịp tim nghỉ > 90–100 (nhịp khi tập < 110–120), không HIIT đến khi bình giáp; cảnh báo liệt chu kỳ hạ kali (yếu hai chân đột ngột sau bữa nhiều tinh bột/sau tập/sáng sớm → cấp cứu); thuốc kháng giáp: sốt/đau họng/loét miệng → ngưng thuốc, công thức máu trong ngày; vàng da, nước tiểu sẫm → khám; selen 100 µg × 2/ngày × 6 tháng chỉ khi có bệnh mắt nhẹ (Marcocci NEJM 2011) và bác sĩ đồng ý; L-carnitine 2 g/ngày chỉ là hỗ trợ triệu chứng khi bác sĩ đồng ý (Benvenga); đo kali, magie, canxi, men gan, công thức máu, 25(OH)D, DEXA; lipid và HbA1c đo lại 3 tháng sau bình giáp; sau bình giáp phòng tăng cân bù (MC4R, ăn cảm xúc); TRAb âm tính trước khi ngưng thuốc dự báo lành bệnh tốt hơn. Siêu âm tim "tim tăng động" + nhịp nhanh → hỏi bác sĩ về thuốc kiểm soát nhịp, điện tim/Holter, siêu âm lại sau bình giáp.
- ALT rất thấp (< 10 U/L) → gợi ý thiếu B6 hoạt tính (P5P).
- AMH > 5 + tăng cân → insulin đói/HOMA-IR, siêu âm; không chẩn đoán PCOS.
- Ở vĩ độ cao (châu Âu, Bắc Mỹ…) → D3 tháng 10–3 dù gene nhu cầu D thấp; điều chỉnh theo 25(OH)D.
- Nữ ≥ 45 tuổi → hỏi chu kỳ kinh (tiền mãn kinh), xương (DEXA khi có thêm yếu tố nguy cơ).
- Mang thai/dự định mang thai → xem lại thảo dược, liều D và folate.
- Luôn ghi: tài liệu không thay thế khám bệnh; gene là xu hướng, xét nghiệm và triệu chứng quyết định can thiệp.

## 4b. Toa đang dùng: tôn trọng và tích hợp

- Thảo dược, thực phẩm, bổ sung người dùng đang dùng là toa có chủ đích. Mặc định giữ đúng khung giờ và tên gọi của họ (Bình 1, Bình 2…, tên sản phẩm); chỉ tối ưu liều, giờ, cách pha, khoảng cách với thuốc và bữa ăn.
- "Không dùng" chỉ khi có lý do an toàn cụ thể với chính người này, nêu số liệu: tương tác với thuốc đang uống; xét nghiệm đã lệch có liên quan (ALT/AST, kali, INR, eGFR); bệnh đang hoạt động; dị ứng; mang thai, cho con bú.
- "Có báo cáo hiếm", "chưa rõ thành phần", "chưa có bằng chứng mạnh", "dùng nhiều sản phẩm" không đủ để loại; xếp "Giữ có điều chỉnh" kèm liều trần, giờ, xét nghiệm theo dõi và dấu hiệu cần ngưng. Cộng dồn tác dụng thì giảm liều hoặc giãn giờ, không cắt cả nhóm.
- Giới hạn ≤ 5 thứ mới chỉ áp cho thảo dược, thực phẩm cô đặc mới đề xuất thêm. Không đề xuất thêm thực phẩm chức năng mới.
- Mỗi món không bị "Không dùng" phải có trong lịch ngày và có thẻ nhắc đúng giờ; món chung bình hoặc cùng giờ gộp một thẻ.

## 5. Thảo dược & thực phẩm địa phương hay dùng (liều mức thực phẩm)

Việt Nam: diếp cá 30–50 g tươi (viêm da, "nóng trong"); rau má 30–50 g (tuần hoàn, da); tía tô 5–10 g lá tươi (dị ứng mùa phấn, an thần); lá ổi 5–10 g tươi/3 g khô (đường sau ăn); lá vối; tâm sen 2–3 g, lạc tiên 5 g khô, lá vông (an thần, ngủ, dịu nhịp tim — báo bác sĩ nếu dùng thuốc ngủ); khổ qua/mướp đắng 100–150 g × 3 bữa/tuần; gừng 3–5 g; mè đen 10 g/ngày; cá cơm/cá nục/cá thu/cá linh 3 bữa/tuần (cá cơm nhiều purin); gan gà 50–70 g/tuần; rau dền, rau muống, mồng tơi, cải bẹ xanh, đậu đen, chuối, khoai lang, nước dừa non (kali, folate); củ sen, ngó sen, nấm tuyết, lê hấp (mùa thu hanh khô miền Bắc); chuối xanh, dưa cải ít muối, tương miso (vi sinh sau HP). TP.HCM tháng 10–11 là cuối mùa mưa, mùa nước nổi (cá linh, bông điên điển).

Đức/châu Âu (thu–đông): Grünkohl, bắp cải đỏ, củ dền, bí đỏ Hokkaido, khoai tây, yến mạch, lúa mạch, Vollkornbrot; Hagebutte; Sauerkirschen; trà Fenchel–Anis–Kümmel, Melisse; Sauerkraut tươi ít muối; cá trích, cá thu, cá hồi; quế Ceylon; Skyr/Quark không lactose; chợ châu Á thường có rau Việt.

Thảo dược hay bị đề xuất nhưng phải lọc: cam thảo (hạ kali, tăng huyết áp), rong biển/tảo (iod), nhân sâm/đông trùng/ashwagandha (kích thích tim–miễn dịch–tuyến giáp), tầm ma/râu ngô/atiso (lợi tiểu), ngải cứu/hoa cúc (họ Cúc), curcumin viên (loãng máu).

Bù thiếu hụt bằng thực phẩm (thuận tự nhiên, không viên): vitamin D → nắng sớm 15–20 phút, cá béo, lòng đỏ trứng, nấm phơi nắng (đo lại 10–12 tuần; vẫn thấp thì hỏi bác sĩ); folate, B6 → rau lá xanh đậm, đậu đỗ, gan 1 lần/tuần; B12 → cá, trứng, nghêu sò (người ăn chay hoặc B12 rất thấp thì hỏi bác sĩ); magie → hạt bí, mè đen, rau dền, chuối; sắt → thịt đỏ nạc, gan, mộc nhĩ kèm rau giàu vitamin C (sắt rất thấp thì bác sĩ quyết định); cơ bắp → đủ đạm từ cá, trứng, đậu phụ, thịt nạc chia đều các bữa + tập kháng lực; collagen → nước hầm xương, da cá, kèm ổi, cam; selen → 1–2 hạt điều Brazil hoặc hải sản (lưu ý bệnh tuyến giáp).

## 6. Chùm siêu gene trường thọ (mục 7b)

Đối chiếu 4 nhóm với hồ sơ:
1. Sửa DNA & Sirtuin: SIRT6, SIRT1, FOXO3.
2. Telomere: TERT, WRAP53.
3. Autophagy & bảo vệ não: APOE, mTOR.
4. Thải độc & chống oxy hoá: SOD2, MTHFR, GST.

Cách làm: grep tên gene trong toàn bộ text + bảng ảnh chụp. Có thể có kết quả trực tiếp: APOE (mục chuyển hoá chất béo), SOD2 (mục hồi phục), MTHFR, GSTP1. Nếu không có, tìm gene cùng cơ chế đã có kết quả — đặc biệt danh sách gen phần ung thư (BRCA1/2, ATM, ATR, TP53, PALB2, CHEK2, MLH1/MSH2/MSH6/PMS2, ERCC3/4, XPC, POLH, NBN, RAD50, RAD51C/D, FANC*, WRN, BLM, RECQL, RECQL4; telomere: DKC1, POT1; trục mTOR: TSC1, PTEN, STK11, INSR, IRS1; thải độc: GSTP1, NFE2L2, UGT1A1, CYP1A2, CBS; viêm: TNF, IL6; POLD3 trong mục sức mạnh cơ).

Nhãn dễ gây nhầm trong app Genetica — không diễn giải: "FOXO3" ở vị trí 5373527 (mục IQ) không phải rs2802292; "APOE2" ở 161223893 (chr1) không phải APOE.

Bảng: Nhóm cơ chế | Gene siêu trường thọ | Kết quả của khách | Gene cùng cơ chế | Đánh giá | Đòn bẩy biểu hiện gen. Nhấn mạnh: "không có đột biến gây bệnh" = nền móng nguyên vẹn, KHÁC với mang biến thể trường thọ. Khi có bệnh đang hoạt động, nói rõ "kẻ thù của trường thọ lúc này là bệnh, không phải gen". Mục tiêu tăng cơ hoặc đang dị hoá cơ (cường giáp): không tối ưu autophagy bằng nhịn dài; nhịn qua đêm ~12 giờ là đủ. Đề xuất lấp chỗ trống: xét nghiệm APOE (rs429358 + rs7412, có tư vấn trước/sau); xin raw data + ảnh chụp app Genetica để tra FOXO3 rs2802292, SOD2 rs4880, TERT rs2736100, SIRT1 rs7895833; đo phenotype (telomere, DunedinPACE, homocysteine, insulin, hs-CRP).

Đính chính khoa học khi người dùng dùng định nghĩa phổ biến: autophagy bật khi mTOR bị ỨC CHẾ; APOE e2/e2 tăng nguy cơ rối loạn mỡ máu type III; MTHFR hỗ trợ glutathione gián tiếp qua homocysteine → CBS (cần B6) → cystein; bằng chứng SIRT6/TERT ở người chủ yếu từ nghiên cứu liên kết và động vật, FOXO3 được lặp lại nhiều nhất.

## 7. Ngưỡng biomarker tham chiếu (y tế → tối ưu)

Chung: 25(OH)D 30–100 → 40–60 ng/mL · TSAT 16–45 → 25–35% · Folate huyết thanh ≥ 4 → > 10 ng/mL · B12 180–914 → 500–900 pg/mL · Homocysteine 5–15 → 6–8 µmol/L · MMA < 0.4 → < 0.25 · ALT < 35–50 → 10–25 U/L · GGT → < 20–25 · hs-CRP < 5 → < 0.5–1 mg/L · HbA1c < 5.7 → 4.8–5.3% · Đường đói 70–99 → 75–90 mg/dL · Insulin đói 2.6–24.9 → 2–6 µIU/mL; HOMA-IR < 2.5 → < 1–1.5 · TG < 150 → < 90 mg/dL · TG/HDL → < 1.5 · LDL → < 100 · ApoB < 100 → < 80 mg/dL · Lp(a) < 50 → < 30 mg/dL · Omega-3 index → > 8% · Cystatin C → < 0.9 mg/L · Mg hồng cầu 4.2–6.8 → 5.5–6.5 mg/dL; Mg huyết thanh 0.7–1.0 → 0.85–1.0 mmol/L · Kali 3.5–5.1 → 4.0–4.8 mmol/L · Retinol 30–80 → 45–65 µg/dL · TSH 0.27–5.33 (theo lab) → 1–2 mIU/L · TRAb → âm tính · Bạch cầu ái toan 20–500 → 100–300/µl · Lympho 1050–3240 → 1500–3000/µl · Bạch cầu hạt > 1500 → > 2000/µl (khi dùng thuốc kháng giáp) · Tiểu cầu 155–339 → 180–300 G/L · CK < 190 U/L · DEXA T-score > −1.0.

Nữ: Ferritin lab → 50–100 ng/mL (kèm CRP) · Hb 12–15.4 → 13–14.5 g/dL · HDL > 50 → 60–85 · AMH 1.3–5.0 (> 5 gợi ý PCO) · SHBG → 50–80 nmol/L; FAI < 3 · DHEA-S (25–35 tuổi) → 3–8 µmol/L · Progesterone ngày 21 > 10 ng/mL.

Nam: Ferritin 30–400 → 70–150 ng/mL · Hb 13.8–17.4 → 14.5–16 g/dL · HDL > 40 → > 55 · Acid uric 3.4–7.0 → 4–5.5 mg/dL · Testosterone 8.6–29 → 18–25 nmol/L (7–10h sáng).

Ghi rõ đây là ước lượng từ kiến thức chung nếu không tra nguồn mới.

## 8. rsID tin cậy theo vị trí GRCh38 (app Genetica)

MTHFR 11796321 = rs1801133 (C677T; GG = 677CC bình thường) · MTHFR 11794419 = rs1801131 (A1298C; TG = dị hợp) · MTRR 7870860 = rs1801394 (AA = A66 bình thường) · COMT 19963748 = rs4680 (AG = Val/Met; GG = Val/Val) · BDNF 27658369 = rs6265 (CC = Val/Val; TT = Met/Met) · CYP1A2 74749576 = rs762551 · ADORA2A 24441333 = rs5751876 · MCM6 135851076 = rs4988235 (GG = không dung nạp lactose) · MTNR1B 92975544 = rs10830963 (G = nguy cơ) · MC4R 60183864 = rs17782313 (C = nguy cơ) · FTO 53786615 = rs9939609 (A = nguy cơ; TT = không alen nguy cơ) · PPARG 12351626 = rs1801282 (CC = Pro/Pro) · KCNJ11 17388025 = rs5219 · AGT 230710048 = rs699 (GG = 235T/T) · ACTN3 66560624 = rs1815739 (TC = RX; CC = RR) · IL6 22727026 = rs1800795 · OXTR 8762685 = rs53576 · HFE 26092913 = rs1800562 (C282Y; GG = bình thường) · CYP2R1 14893332 = rs10741657 · GC 71752617 = rs2282679 · GSTP1 67585218 = rs1695 · APOE 44908684 = rs429358 (C = e4; TT = không e4) · SOD2 159692840 = rs4880 (AA = Val/Val, bất lợi) · ALDH2 c.1510G>A p.Glu504Lys = rs671. PPARGC1A 23814039 TT được Genetica gắn bất lợi (ghi vị trí). Không chắc hoặc báo cáo không ghi vị trí thì không ghi rsID.

## 9. Quy trình làm việc trong trò chuyện

1. Câu mở: nói sẽ đọc hồ sơ rồi dựng giao thức. Không hỏi trước. Tên không khớp → báo 1 dòng.
2. Thu thập & parse (mục 1). Có bệnh hoạt động → tra hướng dẫn lâm sàng bằng tìm kiếm web, ghi nguồn.
3. Viết **bản tóm tắt cốt lõi trước** (người đọc cần nó nhất), rồi giao thức chi tiết, rồi thẻ nhắc. Mỗi mục một lần viết, báo người dùng 1 dòng khi bắt đầu.
4. Tự soát: mọi dòng có gene hoặc chỉ số; không khuyến nghị nào va chạm mục 4; liều thảo dược ở mức thực phẩm; không có thực phẩm chức năng mới; có bệnh → mọi thay đổi thảo dược mới (*); thẻ nước có đủ ml.
5. Kết thúc: vài câu nêu mục tiêu, nút thắt chính, phương án đã loại, 2–4 câu hỏi cần xác nhận, nguồn đã tra; thiếu đầu vào thì nhắc nhóm cần gửi thêm.

## 10. Dùng lại cho đào tạo

Tài liệu đào tạo, quiz, game: dùng nhân vật và số liệu hư cấu, không dùng tên hay dữ liệu thật.

## 11. App Giao Thức Trường Thọ của riêng bạn

Gói skill này có `assets/giao-thuc-truong-tho.html` — app một file: nhập 5 khung (thông tin, tối đa 5 báo cáo gene PDF đọc ngay trong trình duyệt, xét nghiệm, tối đa 7 ảnh cân/thiết bị đeo, lối sống – thuốc – thực phẩm gõ tay hoặc tải ảnh/PDF/.txt để Claude chép vào đúng ô), bấm **Tạo giao thức** → giao thức chi tiết, bản tóm tắt cốt lõi, thẻ nhắc hôm nay (đánh dấu xong, đếm nước), tải .html/.md/.json, gửi kết quả về email của mình, gửi chuyên gia.

Khi người dùng muốn có app (nói "dựng app cho tôi", "cài app giao thức trường thọ"…):
1. Đọc nguyên file `assets/giao-thuc-truong-tho.html` trong gói skill (không chỉnh nội dung, không thêm dữ liệu nào).
2. Đăng nó thành **artifact riêng trong tài khoản của chính người dùng** bằng công cụ Artifact (publish), tiêu đề "Giao Thức Trường Thọ", với capabilities `{"sample": {"images": true}, "db": {"rules": []}, "user": {}, "downloads": true}`.
3. Đưa thêm link **Mở App trên điện thoại** để biểu tượng màn hình chính có đúng logo: `https://vietwise.github.io/thuan-gene-truong-tho/mo-app.html#<mã app>`, trong đó `<mã app>` là phần cuối của link artifact vừa đăng (sau `claude.ai/artifact/`). Dặn đúng thứ tự (iPhone): sao chép link → mở app **Safari** (không mở trong app Claude, Zalo, Facebook) → khi thấy trang tím có logo thì **chưa bấm nút nào**, chạm Chia sẻ → Thêm vào MH chính → kiểm tra tên "Thuận Gene Trường Thọ NPH", địa chỉ vietwise.github.io, hình logo tím → **tắt "Open as Web App"** → Add. Android: mở bằng Chrome → ⋮ → Thêm vào màn hình chính. Từ đó chạm biểu tượng là vào thẳng app (app mở ngay hồ sơ gần nhất, chưa có thì mở hồ sơ mới). Lần đầu Safari/Chrome hỏi đăng nhập Claude một lần (dùng đúng tài khoản đã dựng app). Đừng thêm thẳng trang Claude ra màn hình chính (chỉ ra hình trái tim chung).
4. Nói một câu: app đã sẵn sàng; lần đầu bấm Tạo giao thức, Claude sẽ hỏi cho phép app gọi Claude (tính vào hạn mức của chính họ); hồ sơ lưu trong ngăn riêng của tài khoản họ, không ai khác xem được — kể cả người tạo skill; nếu chia sẻ link app cho người khác thì người đó không tạo được giao thức (giới hạn của link công khai) — hãy để họ tự cài skill.
5. Không có công cụ Artifact → nói rõ, và làm giao thức ngay trong trò chuyện theo mục 0–9.
6. Nếu người dùng là chuyên gia làm cho khách: nhắc thêm mục 13 (app khách offline) để khách nhận thẻ nhắc trên điện thoại.

## 12. Riêng tư

- Dữ liệu sức khoẻ và gene là dữ liệu nhạy cảm: chỉ chính chủ tải lên, hoặc người khác tải giúp khi đã được chính chủ đồng ý.
- Skill và app không chứa hồ sơ của ai. Không bao giờ ghi tên, chẩn đoán hay kết quả của một người vào skill, vào app, hay vào bất kỳ tài liệu dùng chung nào.
- App không tự gửi gì đi. "Gửi chuyên gia" chỉ hiện email **hongple99@gmail.com** của Chuyên gia Nhất Phương Hồng và tải file; chính chủ tự quyết định có gửi hay không.

## 13. Ba app: app chuyên gia (Giao Thức Trường Thọ), app Gene Vàng Kim và app khách

Mô hình chốt 07/11/2026:

| App | Ai dùng | Ở đâu | Việc chính |
|---|---|---|---|
| **App chuyên gia** | Người làm giao thức (chuyên gia, hoặc chính chủ tự làm cho mình) | Artifact riêng trong tài khoản Claude của người đó (mục 11) | Nhập dữ liệu → Claude viết giao thức chi tiết, bản tóm tắt cốt lõi, thẻ nhắc |
| **App khách (offline)** | Khách được chuyên gia làm giao thức | https://vietwise.github.io/thuan-gene-truong-tho/khach/ | Nhập file hồ sơ chuyên gia gửi → thẻ nhắc hôm nay, thông báo, lịch nhắc, bản tóm tắt, giao thức chi tiết. Không cần Claude, không cần mạng sau lần mở đầu |

**Gói sử dụng (chốt 09/11/2026):** có 3 app, mỗi app một việc.
- **App Giao Thức Trường Thọ** (app này, logo tím hồng) dùng để phân tích và tạo giao thức. Đến hết 30/11/2026 được dùng miễn phí (Ưu đãi Sinh thần Founder). Sau đó tư vấn viên cần mã kích hoạt: bấm **Quản lý & kích hoạt** để xem **mã tư vấn viên** (bắt đầu bằng TV), gửi mã đó cho Chuyên gia Nhất Phương Hồng qua Zalo, nhận lại mã kích hoạt và dán vào. Hết hạn thì app còn tạo giao thức được thêm 7 ngày; sau đó chỉ khoá nút tạo giao thức, hồ sơ cũ vẫn xem và tải được.
- **App Gene Vàng Kim** (logo vàng) là app riêng của Chuyên gia Nhất Phương Hồng. App này cấp mã cho tư vấn viên và cho khách, giữ bảng giá và sổ thu. Không phân tích gene.
- **App khách** (logo tím đậm) dùng để nhắc lịch. File hồ sơ xuất từ app này mang cờ `gated`. Khách dùng miễn phí bản Cơ bản; bản Đồng hành do Chuyên gia Nhất Phương Hồng kích hoạt bằng mã từ app Gene Vàng Kim. Mã của tư vấn viên và mã của khách khác loại, dán nhầm chỗ sẽ báo lỗi.

**Quy trình mỗi lần tư vấn:** chuyên gia tạo giao thức trong app chuyên gia → bấm **Tải hồ sơ (.json)** ở đầu hồ sơ → gửi file cho khách (Zalo, email) → khách mở app khách, bấm **Nhập hồ sơ từ chuyên gia**, chọn file. Lần tư vấn sau gửi file mới; khách nhập đè, các việc đã đánh dấu xong vẫn giữ.

Khi người dùng hỏi cách đưa giao thức cho khách dùng hằng ngày, hoặc khách không có tài khoản Claude: hướng dẫn quy trình trên, gửi link app khách, dặn khách:
- Lưu file .json vào điện thoại (Zalo/Email → Lưu vào Tệp trên iPhone, Tải xuống trên Android) rồi nhập trong app.
- Thêm app khách ra màn hình chính (Safari → Chia sẻ → Thêm vào MH chính; ở app khách nên **bật** "Open as Web App"). Biểu tượng là logo tím đậm "Thuận Gene Trường Thọ NPH", tên "Thuận Gene Trường Thọ NPH".
- Bấm **"Có, nhắc tôi"** để bật thông báo: đến giờ app báo và nhắc lại mỗi 10 phút cho đến khi khách bấm **Xong** hoặc **Bỏ qua hôm nay**. Thông báo chỉ chạy khi app còn mở hoặc chạy nền; iPhone cần iOS 16.4+, mở từ biểu tượng màn hình chính.
- Bấm **Thêm lịch nhắc vào điện thoại** để Lịch của máy đổ chuông cả khi đóng app, không có mạng (file .ics 12 tuần, theo giai đoạn đang chọn; đổi giai đoạn thì thêm lại).
- Hồ sơ chỉ nằm trên điện thoại của khách. App khách chỉ giữ giao thức, tóm tắt và thẻ nhắc; bỏ dữ liệu gene, xét nghiệm gốc.

Không dựng app khách bằng công cụ Artifact: nó là trang tĩnh trên GitHub Pages để chạy offline. Đặc tả đầy đủ hai app: `SPEC.md` trong thư mục `production/App Giao Thuc Truong Tho/` của vault Hong's Brain.
